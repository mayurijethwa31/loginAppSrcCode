import { Directive, Input } from '@angular/core';
import { Validator, NG_VALIDATORS, AbstractControl} from '@angular/forms'

@Directive({
  selector: '[appConfirmPassword]',
  providers: [{
    provide: NG_VALIDATORS,
    useExisting: ConfirmPasswordDirective,
    multi: true
  }]
})
export class ConfirmPasswordDirective implements Validator{
@Input() appConfirmPassword:string;
validate(control:AbstractControl):{[key:string]:any} | null{
  const comparePassword = control.parent.get(this.appConfirmPassword);
  if(comparePassword && comparePassword.value !== control.value) {
    return {'isNotEqual' : true};
  }
  return null;
}
  constructor() { }

}
