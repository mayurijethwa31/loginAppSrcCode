import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UtilserviceService {
  
  //data to initialize list of users on dashaboard and home
  data = [{
    id:"1",
    firstName:"mayuri",
    lastName: "jethwa",
    email: "mayu@df.df",
    contactNumber: "7878878787",
    gender: "female",
    age: "23",
    userType: "admin",
  },{
    id:"2",
    firstName:"manisha",
    lastName: "gupta",
    email: "mayu@df.df",
    contactNumber: "7878878787",
    gender: "female",
    age: "21",
    userType: "user",
  },{
    id:"3",
    firstName:"anish",
    lastName: "jain",
    email: "mayu@df.df",
    contactNumber: "7878878787",
    gender: "male",
    age: "32",
    userType: "user",
  }]

  constructor() { }

  /*ngdocs
  * service: UtilserviceService
  * get sign in data from local storage
  */
  getLocalStorageData() {
    return JSON.parse(localStorage.getItem('profileData'));
  }

  /*ngdocs
  * service: UtilserviceService
  * set data to local storage while login
  */
  setLocalStorageData(profileData) {
    localStorage.setItem('profileData',JSON.stringify(profileData));
  }

  /*ngdocs
  * service: UtilserviceService
  * get user detail by id
  */
  getUserById(userId){
    let id = JSON.stringify(userId);
    let userDetails;
    this.data.forEach(function(user){
      if (user.id === id){
        userDetails = user;
      }
    });
    return userDetails;
  }
}
