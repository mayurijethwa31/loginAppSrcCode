import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { UtilserviceService } from '../utilservice.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  localStorageData;
  authenticateUserFlag:boolean;
  incorrectUserDetails: String;
  loginForm = new FormGroup({
  email: new FormControl(''),
  password: new FormControl(''),
  remember: new FormControl('')
});
  constructor(private router:Router, private service:UtilserviceService) { 
  this.localStorageData = new Array();
  this.authenticateUserFlag = true;

  }

  ngOnInit() {
  }

  /*ngdocs
  * component: LoginComponent
  * log in user on submit
  */
  onSubmit(){
    this.localStorageData = this.service.getLocalStorageData();
    this.localStorageData.forEach(localStorageElement => {
      this.authenticateUserFlag = (localStorageElement.email === this.loginForm.value.email &&
     localStorageElement.password === this.loginForm.value.password)});
    console.log(this.authenticateUserFlag);
    if (this.authenticateUserFlag) {
      this.router.navigate(['/home']);
    }
  }

  /*ngdocs
  * component: LoginComponent
  * redirect user to sign up page
  */
  redirectSignUpPage() {
    this.router.navigate(['/signup']);
  }

}
