export interface IUser {
    firstName: String
    lastName: String,
     email: String,
     contactNumber: String,
     password: String,
     gender: String,
     age: String,
     userType: String
}
