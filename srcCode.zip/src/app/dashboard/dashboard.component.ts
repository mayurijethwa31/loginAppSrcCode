import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {UtilserviceService} from '../utilservice.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
data;
  constructor(private router:Router, private service:UtilserviceService) {
    this.data = this.service.data;
   }

  ngOnInit() {
    
  }

  /*ngdocs
  * component: DashboardComponent
  * redirect user to home page
  */
  redirectToHome(){
    this.router.navigate(['/home']);
  }

  /*ngdocs
  * component: DashboardComponent
  * logs out the user
  */
  redirectLogOut() {
    this.router.navigate(['/thankyou']);
  }

}
