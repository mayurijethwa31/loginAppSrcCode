import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import {Router, ActivatedRoute, Params} from '@angular/router';
import { UtilserviceService } from '../utilservice.service';

@Component({
  selector: 'app-edit-profile',
  templateUrl: './edit-profile.component.html',
  styleUrls: ['./edit-profile.component.css']
})
export class EditProfileComponent implements OnInit {
  id:number;
  user;
  userDetails;
  data = this.service.data;
  editForm;
  
  constructor(private route:ActivatedRoute, private service:UtilserviceService, private router:Router) { }

  ngOnInit() {
    this.user = {
      id: this.route.snapshot.params['userid']
    }
    this.route.params.subscribe((params:Params)=>{
      this.user.id = +params['userid'];
      
    });
    this.userDetails = this.service.getUserById(this.user.id);
    this.editForm = new FormGroup({
      contactNumber: new FormControl(this.userDetails.contactNumber),
      gender: new FormControl(this.userDetails.gender),
      age: new FormControl(this.userDetails.age),
      userType: new FormControl(this.userDetails.usertype)
    });
    
    
  }

  /*ngdocs
  * component: EditProfileComponent
  * edit any user
  */
  onSubmit(){
    let editForm =this.editForm;
    let userId = JSON.stringify(this.user.id);
    this.service.data.forEach(function(user){
      if(userId === user.id){
        user.contactNumber = editForm.value.contactNumber;
      user.gender = editForm.value.gender;
      user.age =  editForm.value.age;   
      user.userType =  editForm.value.userType;
      }
    });
    this.router.navigate(['/home']);
  }
  

}
