import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

import { UtilserviceService } from '../utilservice.service';
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  profileDataArr;
  signUpForm = new FormGroup({
    firstName: new FormControl('',[Validators.required,Validators.pattern("^[a-zA-Z]+$")]),
    lastName: new FormControl('', [Validators.required,Validators.pattern("^[a-zA-Z]+$")]),
    email: new FormControl('',[Validators.required]),
    contactNumber: new FormControl('',[Validators.required,Validators.pattern("^[0-9]+$"),Validators.min(10),Validators.maxLength(12)]),
    //password: new FormControl('',[Validators.required,Validators.pattern("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,}).")]),
    password: new FormControl('',[Validators.required]),
    confirmPassword: new FormControl(''),
    gender: new FormControl(''),
    age: new FormControl('',[Validators.required,Validators.pattern("^[0-9]+$")]),
    userType: new FormControl(''),
    termsAndConditions: new FormControl('')
  });

  /*ngdocs
  * component: SignupComponent
  * to sign up a new user
  */
  onSigningUp() {
    this.profileDataArr.push(this.signUpForm.value);
    this.service.setLocalStorageData(this.profileDataArr);
    this.router.navigate(['/login']);
  }
  constructor(private router:Router, private service:UtilserviceService) { 
    this.profileDataArr = new Array();
  }

  ngOnInit() {
    this.profileDataArr = this.service.getLocalStorageData();
  }

}
