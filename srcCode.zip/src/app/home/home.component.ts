import { Component, OnInit } from '@angular/core';
import { Router,ActivatedRoute, ParamMap } from '@angular/router';
import { UtilserviceService } from '../utilservice.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  private id: number;
 data;
 messageDeleted;
  private user;
    constructor(private router:Router,private route: ActivatedRoute, private service: UtilserviceService) { }
  
  /*ngdocs
  * component: HomeComponent
  * redirect to dashboard
  */ 
  redirectToDashboard() {
    this.router.navigate(['/dashboard']);
  }

  /*ngdocs
  * component: HomeComponent
  * redirect to edit user page
  */
  redirectToEditMyProfile() {
    
    this.router.navigate(['/edit']);
  }

  /*ngdocs
  * component: HomeComponent
  * redirect with the particular user id to edit a particular user
  */
  editList(userId) {
    this.router.navigate(['/edit',userId]);
  }

  /*ngdocs
  * component: HomeComponent
  * logs out user
  */
  redirectLogOut() {
    this.router.navigate(['/thankyou']);
  }

  /*ngdocs
  * component: HomeComponent
  * delete user from list
  */
  deleteUser(id) {
    this.service.data.splice(id,1);
    this.messageDeleted = true;
  }

  ngOnInit() {
    this.data = this.service.data;
  }

}
